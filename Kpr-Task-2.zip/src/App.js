import { useState } from "react";

export default function App() {
  const [myItem, Setadd] = useState(0);
  const [stock, setStock] = useState([{ name: "Add", Add: "10" }]);
  const [Incre, setIncre] = useState([
    { name: "Add", Add: 0, count: 100 }
  ]);

  const moveToCart = (e) => {
    let isadd = true;
    let [name, number] = e.target.innerHTML.split(":");
    // console.log(name);

    const newList = stock.map((item, index) => {
      if (item.name === name) {
        if (item.Add > 0) item.Add--;
        else {
          isadd = false;
          alert("Give A Refresh");
        }
      }
      return item;
    });
    console.log(newList);

    const newcount = Incre.map((item, index) => {
      if (item.name === name && isadd) {
        item.Add++;
        Setadd(myItem + item.count);
      }
      return item;
    });
  };
  const minusCart = (e) => {
    let isadd = true;
    let [name, number] = e.target.innerHTML.split(":");
    const newcount = Incre.map((item, index) => {
      if (item.name === name && item.Add > 0) {
      item.Add--;
        Setadd(myItem - item.count);
      }
      return item;
    });
    const newList = stock.map((item, index) => {
      if (item.name === name) {
        item.Add++;
      }
      return item;
    });
  };

  const Decrement = stock.map((item, index) => (
    <button key={index} onClick={moveToCart}>
      {item.name}:{item.Add}
    </button>
  ));

  const Increment = Incre.map((item, index) => (
    <button key={index} onClick={minusCart}>
      {item.name}:{item.Add}
    </button>
  ));

  return (
    <>
      <h1>Increase And Decrease</h1>
      <h2>Add</h2>
      <ul>Increment:{Decrement}&nbsp;&nbsp;Decrement:{Increment}</ul><br /><br />
<div className="Section">   
<h3>Result Here</h3>     
        <p>
          Result is shown Increase Or + or -{Decrement}{Increment}
        </p>
</div>
    </>
  );
}
